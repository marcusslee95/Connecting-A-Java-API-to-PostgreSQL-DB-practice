package com.interviewprep.sanityCheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SanityCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
