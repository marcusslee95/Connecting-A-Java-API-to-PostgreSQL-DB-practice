package com.interviewprep.sanityCheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SanityCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(SanityCheckApplication.class, args);
	}

}
