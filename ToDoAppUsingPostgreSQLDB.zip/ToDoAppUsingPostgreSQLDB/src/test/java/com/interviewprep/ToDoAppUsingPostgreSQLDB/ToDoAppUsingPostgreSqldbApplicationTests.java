package com.interviewprep.ToDoAppUsingPostgreSQLDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToDoAppUsingPostgreSqldbApplicationTests {

	@Test
	void contextLoads() {
	}

}
