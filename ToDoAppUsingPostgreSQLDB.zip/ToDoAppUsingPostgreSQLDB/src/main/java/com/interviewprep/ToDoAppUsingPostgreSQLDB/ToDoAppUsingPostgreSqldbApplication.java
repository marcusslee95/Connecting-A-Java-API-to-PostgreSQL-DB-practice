package com.interviewprep.ToDoAppUsingPostgreSQLDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToDoAppUsingPostgreSqldbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToDoAppUsingPostgreSqldbApplication.class, args);
	}

}
